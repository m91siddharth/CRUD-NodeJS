var express = require('express');
var router = express.Router();
var mongo = require('mongodb').MongoClient;
var objectId = require('mongodb').ObjectID;
var assert = require('assert');
var url = 'mongodb://localhost:27017/test';

/* GET home page. */
/*
router.get('/', function(req, res, next) {
  res.render('index');
  //req.session.errors = null;
});
va r a={
	name:String
},{validation : false};
var a= mongoose("a",a,"actual");
router.get('/test/:id', function(req, res, next){
	var out = req.params.id;
	res.render('test',{output:out});
	a.find()
});
*/
/*router.get('/', function(req, res, next) {
  res.render('index', { title: 'Form Validation ', errors:req.session.error , condition: false, anyArray: [1,2,3] });
  req.session.errors = null;
});
*/


router.get('/', function(req, res, next) {
  res.render('crud', { title: 'CRUD Operations '});
  req.session.errors = null;
});

router.get('/get-data',function (req,res, next) {
	// body...
	var resultArray = [];
	mongo.connect(url,function(err,db){
		assert.equal(null, err);
		var cursor = db.collection('user-data').find();
		cursor.forEach(function(doc,err){
			assert.equal(null, err);
			resultArray.push(doc);
		}, function () {
			db.close();
			res.render('crud',{items:resultArray})
		});
	} );

});
router.post('/insert',function (req,res, next) {
	// body...
	var item = {
		title : req.body.title,
		content : req.body.content,
		author : req.body.author,
	};

	mongo.connect(url,function(err,db){
		assert.equal(null, err);
		db.collection('user-data').insertOne(item, function(err, result){
			assert.equal(null, err);
			console.log('Item inserted');
			db.close();
		});
	} );

	res.redirect('/');
});
/*
var mongo = require('mongodb').MongoClient;
var objectId = require('mongodb').ObjectID;
updateOne({"_id":objectId(id)},{$set:item}
.deleteOne({"_id":objectId(id)}
*/
router.post('/update',function (req,res, next) {
	// body...
		var item = {
		title : req.body.title,
		content : req.body.content,
		author : req.body.author,
	};
	var id = req.body.id;
	mongo.connect(url,function(err,db){
		assert.equal(null, err);
		db.collection('user-data').updateOne({"_id":objectId(id)},{$set:item}, function(err, result){
			assert.equal(null, err);
			console.log('Item updated');
			db.close();
		});
	} );
	
	res.redirect('/');
});
router.post('/delete',function (req,res, next) {
	// body...
	var id = req.body.id;
	mongo.connect(url,function(err,db){
		assert.equal(null, err);
		db.collection('user-data').deleteOne({"_id":objectId(id)}, function(err, result){
			assert.equal(null, err);
			console.log('Item deleted');
			db.close();
		});
	} );
	res.redirect('/');
});
 
/*
router.get('/test/:id/:param2', function(req, res, next){
	res.render('test',{output:req.params.param2});
});*/

router.post('/test/submit',function(req, res, next){
	var id = req.body.id;
	res.redirect('/test/' +id);
});

module.exports = router;
